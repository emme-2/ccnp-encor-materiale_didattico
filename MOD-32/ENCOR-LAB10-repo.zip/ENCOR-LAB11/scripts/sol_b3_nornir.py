#!/usr/bin/env python3
"""
CCNP ENCOR – LAB 11 – Blocco 3: Nornir 3.x
Soluzione commentata

Task 3.1 – InitNornir, esplora inventory
Task 3.2 – Task parallelo: show clock su tutti i router
Task 3.3 – Task di configurazione: push NTP server
Task 3.4 – Filtra con F() e riesegui solo su un sottoinsieme
"""

from nornir import InitNornir
from nornir_netmiko.tasks import netmiko_send_command, netmiko_send_config
from nornir_utils.plugins.functions import print_result
from nornir.core.filter import F

# ─────────────────────────────────────────────────────────────
# TASK 3.1 – Inizializza Nornir e ispeziona l'inventory
# ─────────────────────────────────────────────────────────────

print("=" * 60)
print("TASK 3.1 – InitNornir e ispezione inventory")
print("=" * 60)

# InitNornir carica config.yaml che punta a hosts/groups/defaults
nr = InitNornir(config_file="nornir/config.yaml")

# nr.inventory.hosts → dizionario di oggetti Host
print(f"\nHost nell'inventory: {len(nr.inventory.hosts)}")
for nome, host in nr.inventory.hosts.items():
    # host.hostname    → IP o FQDN
    # host.groups      → lista gruppi
    # host.data        → dizionario dati custom (location, loopback)
    print(f"  {nome:4s} | {host.hostname:17s} | "
          f"groups={[g.name for g in host.groups]} | "
          f"location={host.data.get('location','?')}")

print(f"\nGruppi: {list(nr.inventory.groups.keys())}")


# ─────────────────────────────────────────────────────────────
# TASK 3.2 – Task parallelo: show clock
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 3.2 – show clock (parallelo su tutti i router)")
print("=" * 60)

# nr.run() esegue il task su TUTTI gli host in parallelo
# num_workers è definito in config.yaml (4 thread)
result = nr.run(
    task=netmiko_send_command,
    command_string="show clock",
)

# print_result formatta l'output in modo leggibile
print_result(result)

# Accesso programmatico al risultato di un singolo host:
for host, task_result in result.items():
    if not task_result.failed:
        print(f"  [{host}] clock: {task_result.result.strip()}")


# ─────────────────────────────────────────────────────────────
# TASK 3.3 – Task di configurazione: push NTP server
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 3.3 – Push NTP server su tutti i router")
print("=" * 60)

# netmiko_send_config accetta una lista di comandi
# È equivalente a: config t → ntp server ... → end
config_commands = [
    "ntp server 192.168.122.1",
    "ntp update-calendar",
]

result_cfg = nr.run(
    task=netmiko_send_config,
    config_commands=config_commands,
)

print_result(result_cfg)

# Verifica: leggi la config NTP appena applicata
print("\nVerifica NTP applicata:")
result_verify = nr.run(
    task=netmiko_send_command,
    command_string="show ntp status",
)
print_result(result_verify)


# ─────────────────────────────────────────────────────────────
# TASK 3.4 – Filtra con F() e riesegui su sottoinsieme
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 3.4 – Filter F() – solo router in 'Distribution'")
print("=" * 60)

# F() permette di filtrare l'inventory per attributi dei gruppi o dei dati host
# F(data__location="Distribution") → filtra su host.data["location"]
# Gli operatori di confronto: ==, __contains, __any, ecc.
nr_distribution = nr.filter(F(data__location="Distribution"))

print(f"Host filtrati (location=Distribution): "
      f"{list(nr_distribution.inventory.hosts.keys())}")

# Riesegui show clock solo su questi host
result_filtered = nr_distribution.run(
    task=netmiko_send_command,
    command_string="show clock",
)
print_result(result_filtered)

# ─────────────────────────────────────────────────────────────
# GESTIONE ERRORI – failed_hosts
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("Verifica host con errori (failed_hosts)")
print("=" * 60)

# result.failed_hosts → dizionario degli host che hanno fallito
if result.failed_hosts:
    print(f"  HOST CON ERRORI: {list(result.failed_hosts.keys())}")
else:
    print("  Nessun errore – tutti gli host hanno risposto correttamente.")
