#!/usr/bin/env python3
"""
CCNP ENCOR – LAB 11 – Blocco 2: Netmiko
Soluzione commentata

Task 2.1 – ConnectHandler su R1, show version
Task 2.2 – Loop su 4 router, show ip interface brief + show ip ospf neighbor
Task 2.3 – Backup running-config su file locale
Task 2.4 – Costruisci report.json con i dati raccolti
"""

import json
import os
import re
from netmiko import ConnectHandler
from netmiko.exceptions import NetmikoTimeoutException, NetmikoAuthenticationException

os.makedirs("backup", exist_ok=True)

# ─────────────────────────────────────────────────────────────
# TASK 2.1 – Connessione a R1 con ConnectHandler
# ─────────────────────────────────────────────────────────────

print("=" * 60)
print("TASK 2.1 – ConnectHandler su R1")
print("=" * 60)

# ConnectHandler accetta un dizionario con i parametri di connessione
r1 = {
    "device_type": "cisco_ios",    # ← identifica il driver Netmiko
    "host": "192.168.122.101",
    "username": "admin",
    "password": "cisco123",
    "secret": "cisco123",          # ← enable password
    "global_delay_factor": 2,      # ← moltiplicatore timeout (IOU è lento)
}

try:
    print(f"  Connessione a R1 ({r1['host']})...", end=" ")
    conn = ConnectHandler(**r1)    # ** unpacking del dizionario
    conn.enable()                  # entra in modalità privilegiata
    print("OK")

    output = conn.send_command("show version")

    # Estrai solo le prime 5 righe (versione IOS)
    righe = output.splitlines()
    for riga in righe[:5]:
        print(f"  {riga}")

    conn.disconnect()
    print("  Disconnesso.")

except NetmikoTimeoutException:
    print("ERRORE: timeout – verifica che R1 sia raggiungibile")
except NetmikoAuthenticationException:
    print("ERRORE: autenticazione fallita – verifica username/password")


# ─────────────────────────────────────────────────────────────
# TASK 2.2 – Loop su tutti i router
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 2.2 – Loop su 4 router")
print("=" * 60)

# Carica inventory.json invece di hardcodare i device
with open("inventory.json", "r") as f:
    inventory = json.load(f)

# Template parametri Netmiko (validi per tutti i device)
NETMIKO_DEFAULTS = {
    "device_type": "cisco_ios",
    "secret": "cisco123",
    "global_delay_factor": 2,
}

risultati = {}   # dizionario per raccogliere i dati → usato nei task successivi

for device in inventory["devices"]:
    host = device["hostname"]
    ip   = device["ip"]
    print(f"\n  [{host}] {ip}")

    params = {
        **NETMIKO_DEFAULTS,
        "host":     ip,
        "username": device["username"],
        "password": device["password"],
    }

    try:
        conn = ConnectHandler(**params)
        conn.enable()

        # show ip interface brief
        brief = conn.send_command("show ip interface brief")
        print(f"  --- show ip interface brief ---")
        for r in brief.splitlines()[1:]:   # salta header
            if r.strip():
                print(f"    {r}")

        # show ip ospf neighbor
        ospf_out = conn.send_command("show ip ospf neighbor")
        # conta le righe con neighbor (righe che contengono un IP di neighbor)
        neighbor_lines = [l for l in ospf_out.splitlines()
                          if re.match(r'\s*\d+\.\d+\.\d+\.\d+', l)]
        n_neighbors = len(neighbor_lines)
        print(f"  OSPF neighbor count: {n_neighbors}")

        # Conta interfacce up
        up_count = sum(1 for l in brief.splitlines() if "up" in l.lower() and "up" in l.lower().split()[-1:])

        # Salva per Task 2.4
        risultati[host] = {
            "hostname":         host,
            "ip":               ip,
            "location":         device["location"],
            "ospf_neighbors":   n_neighbors,
            "ospf_detail":      neighbor_lines,
        }

        conn.disconnect()

    except Exception as e:
        print(f"  ERRORE: {e}")
        risultati[host] = {"hostname": host, "ip": ip, "errore": str(e)}


# ─────────────────────────────────────────────────────────────
# TASK 2.3 – Backup running-config
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 2.3 – Backup running-config")
print("=" * 60)

for device in inventory["devices"]:
    host = device["hostname"]
    ip   = device["ip"]

    params = {
        **NETMIKO_DEFAULTS,
        "host":     ip,
        "username": device["username"],
        "password": device["password"],
    }

    try:
        conn = ConnectHandler(**params)
        conn.enable()

        # send_command con use_textfsm=False forza output raw
        running = conn.send_command("show running-config")

        # Salva su file
        filename = f"backup/{host}-config.txt"
        with open(filename, "w") as f:
            f.write(f"! Backup {host} – {ip}\n")
            f.write(running)

        print(f"  [{host}] → {filename}  ({len(running)} bytes)")
        conn.disconnect()

    except Exception as e:
        print(f"  [{host}] ERRORE: {e}")


# ─────────────────────────────────────────────────────────────
# TASK 2.4 – Costruisci e salva report.json
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 2.4 – Salvataggio report.json")
print("=" * 60)

report = {
    "lab": "ENCOR-LAB11",
    "sessione": "11 – Automation & Programmability",
    "dispositivi": list(risultati.values())
}

# json.dump su file – con indent per leggibilità
with open("backup/report.json", "w") as f:
    json.dump(report, f, indent=2)

# Verifica immediata con json.dumps (preview su terminale)
print(json.dumps(report, indent=2))
print("\n  File salvato: backup/report.json")
