#!/usr/bin/env python3
"""
CCNP ENCOR – LAB 11 – Blocco 1: Python & JSON
Soluzione commentata

Task 1.1 – json.load()    : legge da FILE
Task 1.2 – json.loads()   : legge da STRINGA
Task 1.3 – json.dump/dumps: scrive su FILE e STRINGA
Task 1.4 – Gestione errori JSONDecodeError
"""

import json
import os

# ─────────────────────────────────────────────────────────────
# TASK 1.1 – json.load() su file
# Leggi inventory.json e stampa hostname + IP di ogni device
# ─────────────────────────────────────────────────────────────

print("=" * 60)
print("TASK 1.1 – json.load() da file")
print("=" * 60)

# json.load(file_object) → legge da un FILE aperto
# Nota: il file deve essere aperto in modalità lettura testo ('r')
with open("inventory.json", "r") as f:
    inventory = json.load(f)       # ← file object, NON stringa

# inventory è ora un dizionario Python
# inventory["devices"] è una lista di dizionari
for device in inventory["devices"]:
    print(f"  {device['hostname']:4s}  →  {device['ip']}")

# Verifica: type() mostra che il risultato è un dict
print(f"\nTipo restituito da json.load(): {type(inventory)}")


# ─────────────────────────────────────────────────────────────
# TASK 1.2 – json.loads() su stringa
# Simulazione di risposta API: filtra solo platform == "ios"
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 1.2 – json.loads() da stringa")
print("=" * 60)

# Stringa JSON ricevuta (es. da requests.get().text)
api_response_string = '''
{
  "status": "ok",
  "devices": [
    {"hostname": "R1", "platform": "ios",    "ip": "192.168.122.101"},
    {"hostname": "R2", "platform": "ios",    "ip": "192.168.122.102"},
    {"hostname": "FW1","platform": "asa",    "ip": "192.168.122.200"},
    {"hostname": "R3", "platform": "ios",    "ip": "192.168.122.103"},
    {"hostname": "SW9","platform": "nxos",   "ip": "192.168.122.201"}
  ]
}
'''

# json.loads(stringa) → legge da una STRINGA (la 's' sta per string)
data = json.loads(api_response_string)

# List comprehension: filtra solo i device con platform "ios"
ios_devices = [d for d in data["devices"] if d["platform"] == "ios"]

print(f"Device totali nella risposta : {len(data['devices'])}")
print(f"Device con platform 'ios'    : {len(ios_devices)}")
for d in ios_devices:
    print(f"  {d['hostname']}  {d['ip']}")


# ─────────────────────────────────────────────────────────────
# TASK 1.3 – json.dumps() e json.dump()
# Costruisci un dict con i dati di R1, poi:
#   a) serializza in stringa con json.dumps()
#   b) salva su file con json.dump()
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 1.3 – json.dump() e json.dumps()")
print("=" * 60)

r1_data = {
    "hostname": "R1",
    "ip": "192.168.122.101",
    "vendor": "cisco",
    "platform": "ios",
    "loopback": "1.1.1.1",
    "ospf_neighbors": ["R2", "R3"]
}

# json.dumps(dict) → restituisce una STRINGA JSON
# indent=2 → pretty-print con 2 spazi di indentazione
# sort_keys=True → chiavi in ordine alfabetico (utile per diff)
r1_json_string = json.dumps(r1_data, indent=2, sort_keys=True)

print("Output json.dumps() (stringa):")
print(r1_json_string)
print(f"\nTipo restituito: {type(r1_json_string)}")

# json.dump(dict, file_object) → scrive su FILE
os.makedirs("backup", exist_ok=True)
output_file = "backup/r1-data.json"

with open(output_file, "w") as f:
    json.dump(r1_data, f, indent=2, sort_keys=True)   # ← file object

print(f"\nFile scritto: {output_file}")

# Rileggi e verifica
with open(output_file, "r") as f:
    verificato = json.load(f)
print(f"Verifica rilettura – hostname: {verificato['hostname']}")


# ─────────────────────────────────────────────────────────────
# TASK 1.4 – Gestione JSONDecodeError
# JSON malformato: virgola in eccesso (trailing comma)
# ─────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("TASK 1.4 – Gestione JSONDecodeError")
print("=" * 60)

json_malformato = '''
{
  "hostname": "R1",
  "ip": "192.168.122.101",
}
'''
# ↑ La virgola dopo l'ultimo campo è illegale in JSON
#   (è valida in Python ma NON in JSON standard)

try:
    dati = json.loads(json_malformato)
    print("Parsing OK:", dati)

except json.JSONDecodeError as e:
    # e.msg      → descrizione dell'errore
    # e.lineno   → riga dove è stato trovato l'errore
    # e.colno    → colonna
    print(f"ERRORE JSON rilevato:")
    print(f"  Messaggio : {e.msg}")
    print(f"  Posizione : riga {e.lineno}, colonna {e.colno}")
    print(f"  Testo     : {e.doc.strip()[:60]}...")
    print("\nSuggerimento: rimuovi le trailing comma dal JSON")

# ─────────────────────────────────────────────────────────────
# RIEPILOGO: le 4 funzioni JSON
# ─────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("RIEPILOGO – Le 4 funzioni del modulo json")
print("=" * 60)
print("""
  json.load (f)        ← LEGGE  da FILE object  → dict
  json.loads(s)        ← LEGGE  da STRINGA       → dict
  json.dump (obj, f)   ← SCRIVE su FILE object   → None
  json.dumps(obj)      ← SCRIVE su STRINGA       → str

  Mnemonico: la 's' finale = String
             senza 's'     = File
""")
